package com.example.harshita.dao;

import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import com.example.harshita.form.Employee;

public interface EmployeeDao {
public List<Employee> getAllEmployee()throws SQLException;
public Employee getEmployeeById(int eid)throws SQLException;
public Employee getEmployeeByName(String ename)throws SQLException;
public void addEmployee(int eid, String ename, int deptid,int salary, String designation, String email, int mgrid) throws SQLException;
public void deleteEmployee(int eid) throws SQLException;
public List<Employee> getEmployeeByDept(int deptid) throws SQLException;
public List<Employee> getEmployeeByManager(String ename) throws SQLException;
public void updateEmployee(int eid,String ename, int deptid,int salary,String designation,String email,int mgrid) throws SQLException;List<Employee> getManagerName() throws SQLException;
}

