package com.example.harshita.tags;

import javax.servlet.jsp.tagext.TagSupport;

public class FibonacciTag extends TagSupport{
private int number;

}
