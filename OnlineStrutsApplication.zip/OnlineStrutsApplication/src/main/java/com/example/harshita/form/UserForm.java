package com.example.harshita.form;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;

public class UserForm extends ActionForm{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private String username;
private FormFile file;
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public FormFile getFile() {
	return file;
}
public void setFile(FormFile file) {
	this.file = file;
}

public UserForm() {
	super();
	// TODO Auto-generated constructor stub
}
public UserForm(String username, FormFile file) {
	super();
	this.username = username;
	this.file = file;
}
}
