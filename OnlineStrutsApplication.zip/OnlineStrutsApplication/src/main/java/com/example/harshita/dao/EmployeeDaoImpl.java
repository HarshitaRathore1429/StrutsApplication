package com.example.harshita.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.example.harshita.form.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public List<Employee> getAllEmployee() throws SQLException {
		List<Employee> employees = new ArrayList<Employee>();
		Connection conn = ConnectionMaster.getConnection();
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("Select * from employee");
		while (rs.next()) {
			employees.add(new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5),
					rs.getString(6), rs.getInt(7)));
		}
		employees.stream().forEach(e -> System.out.println(e));
		return employees;
	}

	@Override
	public Employee getEmployeeById(int eid) throws SQLException {
		Connection conn = ConnectionMaster.getConnection();
		Employee e1 = null;
		PreparedStatement pst = conn.prepareStatement("select * from employee where eid=?");
		pst.setInt(1, eid);
		ResultSet rs = pst.executeQuery();
		if (rs.next())
			e1 = new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5),
					rs.getString(6), rs.getInt(7));
		return e1;
	}

	@Override
	public void addEmployee(int eid, String ename, int deptid,int salary, String designation, String email, int mgrid) throws SQLException {
		Connection conn = ConnectionMaster.getConnection();
		PreparedStatement pst = conn.prepareStatement(
				"insert into employee(eid,ename,deptid,salary,designation,email,mgrid) values(?,?,?,?,?,?,?)");
		pst.setInt(1, eid);
		pst.setString(2, ename);
		pst.setInt(3, deptid);
		pst.setInt(4, salary);
		pst.setString(5,designation);
		pst.setString(6,email);
		pst.setInt(7,mgrid);
		pst.executeUpdate();
	}

	@Override
	public void deleteEmployee(int eid) throws SQLException {
		Connection conn = ConnectionMaster.getConnection();
		PreparedStatement ps = conn.prepareStatement("delete from employee where eid=?");
		ps.setInt(1, eid);
		ps.executeUpdate();
	}

	@Override
	public List<Employee> getEmployeeByDept(int deptid) throws SQLException {
		List<Employee> e1 = new ArrayList<Employee>();
		Connection conn = ConnectionMaster.getConnection();
		PreparedStatement ps = conn.prepareStatement("select * from employee where deptid =?");
		ps.setInt(1, deptid);
		ResultSet rs = ps.executeQuery();
		while (rs.next())
			e1.add(new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5),
					rs.getString(6), rs.getInt(7)));
		return e1;

	}

	@Override
	public List<Employee> getManagerName() throws SQLException {
		List<Employee> e1=new ArrayList<Employee>();
		Connection conn=ConnectionMaster.getConnection();
		PreparedStatement ps=conn.prepareStatement("select m.ename as mname from employee e join employee m on e.mgrid=m.eid group by mname;");
		ResultSet rs=ps.executeQuery();
		while(rs.next())
			e1.add(new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5),
					rs.getString(6), rs.getInt(7)));
		return e1;
	}

	@Override
	public List<Employee> getEmployeeByManager(String ename) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateEmployee(int eid, String ename, int deptid,int salary, String designation, String email, int mgrid) throws SQLException {
		Connection conn = ConnectionMaster.getConnection();
		PreparedStatement pst = conn.prepareStatement("update employee set ename=?,deptid=?,salary=?, designation=?,email=?,mgrid=? where eid=?");
		pst.setString(1, ename);
		pst.setInt(2, deptid);
		pst.setInt(3, salary);
		pst.setString(4, designation);
		pst.setString(5,email);
		pst.setInt(6, mgrid);
		pst.setInt(7,eid);
		pst.executeUpdate();
	}

	@Override
	public Employee getEmployeeByName(String ename) throws SQLException {
		Connection conn = ConnectionMaster.getConnection();
		Employee e1 = null;
		PreparedStatement pst = conn.prepareStatement("select * from employee where ename=?");
		pst.setString(1, ename);
		ResultSet rs = pst.executeQuery();
		if (rs.next())
			e1 = new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5),
					rs.getString(6), rs.getInt(7));
		return e1;
	}
}
