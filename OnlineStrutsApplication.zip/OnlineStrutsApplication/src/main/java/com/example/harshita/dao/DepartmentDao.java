package com.example.harshita.dao;

import java.sql.SQLException;
import java.util.List;

import com.example.harshita.form.Department;
public interface DepartmentDao {
	public List<Department> getAllDepartment()throws SQLException;
	public Department getDepartmentByDeptId(int deptid)throws SQLException;
	public void addDepartment(Department department) throws SQLException;
	public void deleteDepartment(int deptid) throws SQLException;
}
