package com.example.harshita.form;

import org.apache.struts.action.ActionForm;

public class UserUpdateOrDelete extends ActionForm{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private int id;

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public UserUpdateOrDelete(int id) {
	super();
	this.id = id;
}

public UserUpdateOrDelete() {
	super();
}


}
