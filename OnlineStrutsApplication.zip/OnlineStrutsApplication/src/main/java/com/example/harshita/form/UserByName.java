package com.example.harshita.form;
import org.apache.struts.action.ActionForm;

public class UserByName extends ActionForm{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private String ename;


public UserByName(String ename) {
	super();
	this.ename = ename;
}

public UserByName() {
	super();
	// TODO Auto-generated constructor stub
}


public String getEname() {
	return ename;
}

public void setEname(String ename) {
	this.ename = ename;
}
}
