package com.example.harshita.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.example.harshita.*;
import com.example.harshita.form.Department;

public class DepartmentDaoImpl implements DepartmentDao{

	@Override
	public List<Department> getAllDepartment() throws SQLException {
		List<Department> departments=new ArrayList<Department>();
		Connection conn=ConnectionMaster.getConnection();
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery("Select * from department");
		while(rs.next()) {
			departments.add(new Department(rs.getInt(1),rs.getString(2),rs.getString(3)));
		}
		departments.stream().forEach(e->System.out.println(e));
		return  departments;
	}
	@Override
	public Department getDepartmentByDeptId(int deptid) throws SQLException {
		Connection conn=ConnectionMaster.getConnection();
		Department d1=null;
		PreparedStatement pst=conn.prepareStatement("select * from department where deptid=?");
		pst.setInt(1, deptid);
		ResultSet rs=pst.executeQuery();
		if(rs.next())
			d1=new Department(rs.getInt(1),rs.getString(2),rs.getString(3));
		return d1;
	}

	@Override
	public void addDepartment(Department department) throws SQLException {
		Connection conn=ConnectionMaster.getConnection();
		PreparedStatement pst=conn.prepareStatement("insert into department(deptid,dname,city) values(?,?,?)");
		pst.setInt(1, department.getDeptid());
		pst.setString(2,department.getDname());
		pst.setString(3, department.getCity());
		pst.executeUpdate();
	}
	@Override
	public void deleteDepartment(int deptid) throws SQLException {
		Connection conn=ConnectionMaster.getConnection();
		PreparedStatement ps = conn.prepareStatement("delete from department where deptid=?");
		ps.setInt(1, deptid);
		ps.executeUpdate();
	}
}
