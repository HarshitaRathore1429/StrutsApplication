package com.example.harshita.form;

import org.apache.struts.action.ActionForm;
public class DispatchForm extends ActionForm{
private String mcall;

public DispatchForm(String mcall) {
	super();
	this.mcall = mcall;
}

public DispatchForm() {
	super();
	// TODO Auto-generated constructor stub
}

public String getMcall() {
	return mcall;
}

public void setMcall(String mcall) {
	this.mcall = mcall;
}
}
