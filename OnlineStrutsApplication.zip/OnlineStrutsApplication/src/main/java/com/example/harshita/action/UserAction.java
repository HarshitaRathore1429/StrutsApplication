package com.example.harshita.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.example.harshita.dao.DepartmentDaoImpl;
import com.example.harshita.form.User;

public class UserAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		User user=(User)form;
		if(user.getUsername().equals("admin") && user.getPassword().equals("123")) {
			request.setAttribute("departments", new DepartmentDaoImpl().getAllDepartment());
			return  mapping.findForward("loginsuccess");
		}
		else
		{
			request.setAttribute("message", "login failes");
		 	return mapping.findForward("failure");
		}
	}
	

}
