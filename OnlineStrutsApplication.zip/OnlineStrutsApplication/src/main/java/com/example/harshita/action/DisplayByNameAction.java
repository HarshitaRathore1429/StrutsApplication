package com.example.harshita.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.example.harshita.dao.EmployeeDaoImpl;
import com.example.harshita.form.UserByName;

public class DisplayByNameAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		UserByName u=(UserByName)form;
		request.setAttribute("employees", new EmployeeDaoImpl().getEmployeeByName(u.getEname()));
		return mapping.findForward("successemployee");
	}
}
