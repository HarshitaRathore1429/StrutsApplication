package com.example.harshita.action;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

public class MyDispatchAction extends DispatchAction {
	public ActionForward add(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setAttribute("message", "add button hitted");
		return mapping.findForward("success");
	}

	public ActionForward delete(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setAttribute("message", "delete button hitted");
		return mapping.findForward("success");
	}

	public ActionForward update(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setAttribute("message", "update button hitted");
		return mapping.findForward("success");
	}
protected Map getKeyMapMethod()
{
	Map<String,String> m1=new HashMap<String,String>();
	m1.put("dispatch.form.add","addCall");
	m1.put("dispatch.form.update","updateCall");
	m1.put("dispatch.form.delete","deleteCall");
	return m1;
	
}
}
